# Part 3 answers

1. We will use text messaging to communicate, with a few in person meetings towards the end of the project.
2. A few times, the meetings should last as long as we need them to, and it is up to you to keep up with meetings you missed.
3. We can split up the work and have specific roles on what to do. But for the early part of the project we will work together on gathering data
4. Our overall goal is to find what factors help with a movie's success in the box office.

# Part 4 Answers
1. Finding Datasets based off specific criteria by November 04,2024.
2. Cummilate based off of everyones ideas a specific question for the project by November 5th
3. Once we have the data, we need to finalize our roles in the project by November 6th
4. Once we have our roles, we complete our tasks to finish the project's code by November 14th
5. Then we work up the presentation by the 16th

